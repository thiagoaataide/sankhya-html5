package br.com.sankhya.pcfi;

import br.com.sankhya.extensions.eventoprogramavel.EventoProgramavelJava;
import br.com.sankhya.jape.EntityFacade;
import br.com.sankhya.jape.dao.JapeFactory;
import br.com.sankhya.jape.event.PersistenceEvent;
import br.com.sankhya.jape.event.TransactionContext;
import br.com.sankhya.jape.vo.DynamicVO;
import br.com.sankhya.modelcore.util.EntityFacadeFactory;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Cadastre esta classe como Evento Programável da entidade AnexoSistema
 * (TSIANX), no evento Após Inserir.
 */
public class AtualizaImagemItemPcfi implements EventoProgramavelJava {
    private static final String INSTANCIA = "AD_PCFIITE";
    private static final Pattern PK_ITEM = Pattern.compile("^(\\d+)_(\\d+)_AD_PCFIITE$");

    @Override
    public void afterInsert(PersistenceEvent event) throws Exception {
        DynamicVO anexo = (DynamicVO) event.getVo();
        if (!INSTANCIA.equals(anexo.asString("NOMEINSTANCIA"))) {
            return;
        }

        Matcher matcher = PK_ITEM.matcher(anexo.asString("PKREGISTRO"));
        if (!matcher.matches()) {
            return;
        }

        String chaveArquivo = anexo.asString("CHAVEARQUIVO");
        if (chaveArquivo == null || chaveArquivo.trim().isEmpty()) {
            throw new IllegalStateException("AnexoSistema sem CHAVEARQUIVO.");
        }

        DynamicVO parametro = JapeFactory.dao("ParametroSistema")
                .findOne("CHAVE = 'FREPBASEFOLDER'");
        String diretorioBase = parametro.asString("TEXTO");
        if (diretorioBase == null || diretorioBase.trim().isEmpty()) {
            throw new IllegalStateException("Parâmetro FREPBASEFOLDER não configurado.");
        }

        Path diretorioAnexos = Paths.get(diretorioBase, "Sistema", "Anexos", INSTANCIA)
                .toAbsolutePath().normalize();
        Path arquivo = diretorioAnexos.resolve(chaveArquivo).normalize();
        if (!arquivo.startsWith(diretorioAnexos) || !Files.isRegularFile(arquivo)) {
            throw new IllegalStateException("Arquivo do AnexoSistema não encontrado.");
        }

        byte[] imagem = Files.readAllBytes(arquivo);
        BigDecimal nupcfi = new BigDecimal(matcher.group(1));
        BigDecimal sequencia = new BigDecimal(matcher.group(2));
        EntityFacade facade = EntityFacadeFactory.getDWFFacade();
        DynamicVO item = (DynamicVO) facade.findEntityByPrimaryKeyAsVO(
                INSTANCIA, new Object[]{nupcfi, sequencia});
        item.setProperty("IMAGEM", imagem);
        facade.saveEntity(INSTANCIA, item);
    }

    @Override public void beforeInsert(PersistenceEvent event) throws Exception { }
    @Override public void beforeUpdate(PersistenceEvent event) throws Exception { }
    @Override public void afterUpdate(PersistenceEvent event) throws Exception { }
    @Override public void beforeDelete(PersistenceEvent event) throws Exception { }
    @Override public void afterDelete(PersistenceEvent event) throws Exception { }
    @Override public void beforeCommit(TransactionContext context) throws Exception { }
}
